package ru.raiffeisen.cources.atm.soapclient;

import ru.raiffeisen.cources.atm.ScoreTypeEnum;
import ru.raiffeisen.cources.atm.model.money.Money;
import ru.raiffeisen.cources.atm.model.score.DumpType;
import ru.raiffeisen.cources.atm.soap.IAccountOperations;

import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.MalformedURLException;
import java.net.URL;

public class Client {
    public static void main(String[] args) {
        try {
            URL url = new URL("http://localhost:9997/soap?wsdl");
            QName qName = new QName("http://atm.cources.raiffeisen.ru/",
                    "ATMService");
            Service service = Service.create(url, qName);
            IAccountOperations accountOperations = service.getPort(IAccountOperations.class);

            System.out.println(accountOperations.printATM());
            accountOperations.dump(DumpType.XML);
            System.out.println("-400 RUR from CURRENT score");
            accountOperations.getMoneyFromScore
                    (new Money(400, "RUR"), ScoreTypeEnum.CURRENT);
            System.out.println(accountOperations.printATM());
            accountOperations.dump(DumpType.XML);
            System.out.println("-200 RUR from DEBET score");
            accountOperations.getMoneyFromScore
                    (new Money(200, "RUR"), ScoreTypeEnum.DEBET);
            System.out.println(accountOperations.printATM());
            accountOperations.dump(DumpType.XML);
            System.out.println("-1100 RUR from CREDIT score");
            accountOperations.getMoneyFromScore
                    (new Money(1100, "RUR"), ScoreTypeEnum.CREDIT);
            System.out.println(accountOperations.printATM());
            accountOperations.dump(DumpType.XML);


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }
}
