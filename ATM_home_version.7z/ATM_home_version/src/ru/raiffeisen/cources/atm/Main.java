package ru.raiffeisen.cources.atm;

import ru.raiffeisen.cources.atm.model.score.DumpType;

import javax.xml.bind.JAXBException;

public class Main {

    public static void main(String[] args) throws JAXBException {
        ATM atm1 = new ATM();
        atm1.dump(DumpType.JSON);
        atm1.restore(DumpType.JSON);
        System.out.println(atm1.toString());

        ATM atm2 = new ATM();
        System.out.println(atm2.toString());
        atm2.dump(DumpType.XML);
        atm2.restore(DumpType.XML);
        System.out.println(atm2.toString());
    }
}
