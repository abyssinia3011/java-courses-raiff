package ru.raiffeisen.cources.atm.soap;

import ru.raiffeisen.cources.atm.ScoreTypeEnum;
import ru.raiffeisen.cources.atm.model.money.Money;
import ru.raiffeisen.cources.atm.model.score.DumpType;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.JAXBException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC)
public interface IAccountOperations {
    @WebMethod void addMoneyToScore(Money money, ScoreTypeEnum choice);
    @WebMethod String printATM();
    @WebMethod void dump(DumpType dumpType) throws JAXBException;
    @WebMethod Money getMoneyFromScore(Money money, ScoreTypeEnum choice);
}
